//const { Sequelize, DataTypes } = require('sequelize');



// const expenseType = sequelize.define('expense_type', {
	// //Model attributes are defined here
	// expense_description: {
		// type: DataTypes.STRING,
		// allowNull: false
	// }
	// }, {
	  // tableName: 'expense_type',
	  // timestamps: false //otherwise sequelize will pass the created_at and updated_at columns which I dont have so the insert operation will error out
	// });
	
	
module.exports = function(sequelize, DataTypes){
	return sequelize.define('expense_description', {
	// Model attributes are defined here
	expense_description: {
		type: DataTypes.STRING,
		allowNull: false
	}
	}, {
		tableName: 'expense_description', //to force a table name otherise it is the model name but pluralized
		//timestamps: false //otherwise sequelize will pass the created_at and updated_at columns which I dont have so the insert operation will error out
	});
};