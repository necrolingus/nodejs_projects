// const { Sequelize } = require('sequelize');

// const User = sequelize.define('User', {
  // //Model attributes are defined here
	// firstName: {
		// type: DataTypes.STRING,
		// allowNull: false
	// },
		// lastName: {
		// type: DataTypes.STRING
		// //allowNull defaults to true
	// }
	// }, {
		// tableName: 'users',
		// timestamps: false //otherwise sequelize will pass the created_at and updated_at columns which I dont have so the insert operation will error out
	// });

// `sequelize.define` also returns the model
// console.log(User === sequelize.models.User); // true


module.exports = function(sequelize, DataTypes){
	return sequelize.define('users', {
		firstName: {
			type: DataTypes.STRING,
			allowNull: false // allowNull defaults to true
		},
		lastName: {
			type: DataTypes.STRING,
			allowNull: false
			
		}
		}, {
			tableName: 'users',
			//timestamps: false //otherwise sequelize will pass the created_at and updated_at columns which I dont have so the insert operation will error out
		});
};