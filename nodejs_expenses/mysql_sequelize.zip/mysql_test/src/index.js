const dbInit = require('./db/db_init.js') //it exports the models



// async function db_stuff(){ //you MUST put await in a function and then call that function. It is a weird JS limitation.
	// try {
		// await sequelize.authenticate();	//if we dont use await here any errors will sneak past our catch block and we will get an unhandled promis rejection warning
	// }
	// catch (e) {
		// console.log('In the error')
		// console.error(e);
		
	// }
// }


async function create_expense(){
	//const expense = await dbInit.expenseDescriptionModel.create({expense_description: 'leigh_test222'}, { fields: ['expense_description'] });
	const expense = await dbInit.expenseDescriptionModel.create({expense_description: 'leigh_test222'});
	console.log("expense's auto-generated ID:", expense.id);
}


//db_stuff()

create_expense()


console.log('At the end')


