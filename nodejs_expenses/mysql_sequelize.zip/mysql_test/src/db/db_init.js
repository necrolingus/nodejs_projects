//this is the same as const Sequelize = require('sequelize').Sequelize;
//or {x,y} = require('foo'} is the same as x = require('foo').x and y = require('foo').y
const { Sequelize, DataTypes } = require('sequelize');
const Users = require('../models/user.js')
const expenseDescription = require('../models/expense_description.js')

const sequelize = new Sequelize('node_test', 'xxxxxxx', 'xxxxx', {
	host: 'localhost',
	dialect: 'mysql' // one of 'mysql' | 'mariadb' | 'postgres' | 'mssql'
});

var user_init = Users( sequelize, DataTypes );
var expenseDescription_init = expenseDescription( sequelize, DataTypes );


async function model_sync(){ //you MUST put await in a function and then call that function. It is a weird JS limitation.
	try {
		// await user_init.sync({ force: false })
		// await expenseDescription_init.sync({ force: false }); //force true will drop table if it exists and recreate it
		await sequelize.sync({ force: false }); //will sync ALL models
	}
	catch (e) {
		console.log('In the error for model sync')
		console.error(e);
		
	}
}

model_sync()

module.exports = {
    userModel : user_init,
    expenseDescriptionModel : expenseDescription_init
};